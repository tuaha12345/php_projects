<link rel="icon" href="images/f3.png" type="image/ico">
<?php
  require('connection.php');

  if(isset($_GET['id']) )
  { 
    $getid=$_GET['id'];

    $sql="SELECT * FROM বাড়িভাড়া WHERE sl=$getid";
    $query=$connection->query($sql);
    $data=mysqli_fetch_assoc($query); 

    $sl =$getid;
    $ভাড়াটিয়ার_নাম =$data['ভাড়াটিয়ার_নাম'];
    $মোবাইল =$data['মোবাইল'];
    $চলতি_মাসের_নাম=$data['চলতি_মাসের_নাম'];
    $মাসিক_ভাড়ার_পরিমান=$data['মাসিক_ভাড়ার_পরিমান'];
    $বকেয়া=$data['বকেয়া'];
    $মোট_টাকার_পরিমান=$data['মোট_টাকার_পরিমান'];
    $পরিশোধকৃত_টাকার_পরিমান =$data['পরিশোধকৃত_টাকার_পরিমান'];
    $বকেয়া_রইল=$data['বকেয়া_রইল'];
    $তারিখ_ও_বার=$data['তারিখ_ও_বার'];

    // echo $ভাড়াটিয়ার_নাম ;
  }

// <br /><b>Notice</b>:  Undefined variable: ভাড়াটিয়ার_নাম in <b>C:\xampp\htdocs\AbdurRahman\edit.php</b> on line <b>80</b><br />
  if(isset($_POST['edit']))
  {  

    $sl =$_POST['SL'];
    $ভাড়াটিয়ার_নাম =$_POST['ভাড়াটিয়ার_নাম'];
    $মোবাইল =$_POST['মোবাইল'];
    $চলতি_মাসের_নাম=$_POST['চলতি_মাসের_নাম'];
    $মাসিক_ভাড়ার_পরিমান=$_POST['মাসিক_ভাড়ার_পরিমান'];
    $বকেয়া=$_POST['বকেয়া'];
    $মোট_টাকার_পরিমান=$_POST['মোট_টাকার_পরিমান'];
    $পরিশোধকৃত_টাকার_পরিমান =$_POST['পরিশোধকৃত_টাকার_পরিমান'];
    $বকেয়া_রইল=$_POST['বকেয়া_রইল'];
    $তারিখ_ও_বার=$_POST['তারিখ_ও_বার'];

     $sql="UPDATE বাড়িভাড়া SET 
           ভাড়াটিয়ার_নাম='$ভাড়াটিয়ার_নাম',মোবাইল='$মোবাইল',চলতি_মাসের_নাম='$চলতি_মাসের_নাম',মাসিক_ভাড়ার_পরিমান='$মাসিক_ভাড়ার_পরিমান',বকেয়া='$বকেয়া',মোট_টাকার_পরিমান='$মোট_টাকার_পরিমান',পরিশোধকৃত_টাকার_পরিমান='$পরিশোধকৃত_টাকার_পরিমান',
           বকেয়া_রইল='$বকেয়া_রইল',তারিখ_ও_বার='$তারিখ_ও_বার' WHERE SL='$sl' ";

      if(mysqli_query($connection,$sql)==True)
      {
        // echo "DATA UPdated";
      }
      else{
        echo $sql."Data not UPdated";
      }
  }

  
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit/print</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <style type="text/css">
    .container{
      width: 70%;
      text-align: start;
      border-radius: 5px;
      background-color:#ECEFEF;
      padding-left:50px;

    }
    div{
      margin: 50px;
    }
    form{
      padding-top: 30px;
      padding-bottom: 30px;
    }
    input{
      border: none;
      background: none;
    } 
    #roshid{
      border:2px solid dimgray;
/*      width:400px;*/
      width:47%;
      margin-left:27%;
    }
  </style>
</head>
<body>
   
  <div class="container text-start border main_div">

        <div class="text-center">
          <h5  id="roshid" class="py-3 my-2">ঘর/বাসা ভাড়ার টাকা আদায়ের রশিদ</h5>
          <h3>আব্দুর রহমান ভিলা </h3>
          <h6>দাপা ইদ্রাকপুর(সর্দারবাড়ি মসজিদ বাজার রোড)ফতুল্লা নারায়ণগঞ্জ</h6>
          <p>মোবাইল : 0১৭৫২০৩৬২৮৫ , 0১৮৩৭৭৫৫৬৩৪</p>
        </div>

  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

  SL: <input type="text" name="SL" value="<?php echo $sl; ?> " ><br><br>
  ভাড়াটিয়ার_নাম : <input type="text" name="ভাড়াটিয়ার_নাম" value="<?php echo $ভাড়াটিয়ার_নাম ; ?>" ><br><br>
   মোবাইল  : <input type="text" name="মোবাইল" value="<?php echo $মোবাইল  ; ?>" ><br><br>
  মাসের নাম : <input type="text" name="চলতি_মাসের_নাম" value="<?php echo $চলতি_মাসের_নাম ; ?>" ><br><br>
  মাসিক_ভাড়ার_পরিমান : <input type="text" name="মাসিক_ভাড়ার_পরিমান" value="<?php echo $মাসিক_ভাড়ার_পরিমান ; ?>" ><br><br>
  পূর্বের বকেয়া : <input type="text" name="বকেয়া" value="<?php echo $বকেয়া; ?>" ><br><br>
  মোট_টাকার_পরিমান : <input type="text" name="মোট_টাকার_পরিমান" value="<?php echo $মোট_টাকার_পরিমান ; ?>" ><br><br>
  পরিশোধকৃত_টাকার_পরিমান : <input type="text" name="পরিশোধকৃত_টাকার_পরিমান" value="<?php echo $পরিশোধকৃত_টাকার_পরিমান; ?>" ><br><br>
  বকেয়া_রইল/টাকা পাবো : <input type="text" name="বকেয়া_রইল" value="<?php echo $বকেয়া_রইল; ?>" ><br><br>
  তারিখ_ও_বার : <input type="text" name="তারিখ_ও_বার" value="<?php echo $তারিখ_ও_বার ; ?>" ><br><br>
   

 <div class="d-flex  position-relative " style="margin-top: 20px; margin-left: 0px; margin-bottom: 0px;">  
   <a href="index.php" ><img src="images/pre1.png" height="47px" width="47px" ></a>
   <input href="index.php" type="submit" name="edit" value="Edit" class="btn btn-success position-absolute end-0 py-2" >

  </div> 
</form>
  </div>

</body>
</html>



