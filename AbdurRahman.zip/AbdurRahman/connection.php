<?php
$hostname='localhost';
$username='root';
$password='';
$dbname='বাড়িওয়ালা';

$connection=new mysqli($hostname,$username,$password,$dbname); #OPPS way
#$connection=mysqli_connect($hostname,$username,$password,$dbname); procedural way 
if($connection->connect_error)
{
  die("Connection falied".$connection->connect_error);
}
// echo 'Connection sucessful';
?>
