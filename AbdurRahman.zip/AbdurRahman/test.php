<?php
  require('connection.php');

  if(isset($_GET['SL']) )
  { 
    $getid=$_GET['SL'];

    $sql="SELECT * FROM বাড়িভাড়া  WHERE SL=$getid";
    $query=$connection->query($sql);
    $data=mysqli_fetch_assoc($query); 

    $id=$data['SL'];
    $name=$data['ভাড়াটিয়ার_নাম'];
    $gender=$data['চলতি_মাসের_নাম'];
  
  }

  if(isset($_POST['edit']))
  {  
     $id=$_POST['SL'];
      $name=$_POST['ভাড়াটিয়ার_নাম'];
    $gender=$_POST['চলতি_মাসের_নাম'];

     $sql="UPDATE বাড়িভাড়া  SET 
           ভাড়াটিয়ার_নাম='$name',চলতি_মাসের_নাম='$gender' WHERE SL='$id' ";

      if(mysqli_query($connection,$sql)==True)
      {
        echo "DATA UPdated";
      }
      else{
        echo $sql."Data not UPdated";
      }
  }

  
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Form Validation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <style type="text/css">
    .container{
      width: 40%;
      height: 50%;
      border-radius: 5px;
    }
    div{
      margin: 50px;
    }
    form{
      padding-top: 30px;
      padding-bottom: 30px;
    }
  </style>
</head>
<body>
  <div class="container text-center bg-info-subtle border border-info">
      <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <h1>Registration Form</h1>
  Name: <input type="text" name="ভাড়াটিয়ার_নাম" value="<?php echo $name; ?> "><br><br>
  Gender: <input type="text" name="চলতি_মাসের_নাম" value="<?php echo $gender; ?> "><br><br>
  <input type="text" name="SL" value="<?php echo $id; ?> " hidden>
  <input type="submit" name="edit" value="Edit" class="btn btn-success ">
</form>
  </div>

</body>
</html>


