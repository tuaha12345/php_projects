<link rel="icon" href="images/f3.png" type="image/ico">
<?php
  require('connection.php');

  if(isset($_POST['submit']))
  {
     
  if(isset($_POST['sl']) && isset($_POST['ভাড়াটিয়ার_নাম']) && isset($_POST['মোবাইল']) && isset($_POST['চলতি_মাসের_নাম']) && isset($_POST['মাসিক_ভাড়ার_পরিমান']) && isset($_POST['বকেয়া']) && isset($_POST['পরিশোধকৃত_টাকার_পরিমান']) && isset($_POST['তারিখ_ও_বার']))
  { 
    $sl =$_POST['sl'];
    $ভাড়াটিয়ার_নাম =$_POST['ভাড়াটিয়ার_নাম'];
    $মোবাইল =$_POST['মোবাইল'];
    $চলতি_মাসের_নাম=$_POST['চলতি_মাসের_নাম'];
    $মাসিক_ভাড়ার_পরিমান=$_POST['মাসিক_ভাড়ার_পরিমান'];
    $বকেয়া=$_POST['বকেয়া'];
    $মোট_টাকার_পরিমান=$মাসিক_ভাড়ার_পরিমান + $বকেয়া;
    $পরিশোধকৃত_টাকার_পরিমান =$_POST['পরিশোধকৃত_টাকার_পরিমান'];
    $বকেয়া_রইল=$মোট_টাকার_পরিমান - $পরিশোধকৃত_টাকার_পরিমান;
    $তারিখ_ও_বার=$_POST['তারিখ_ও_বার'];

    $sql="INSERT INTO বাড়িভাড়া  (sl,ভাড়াটিয়ার_নাম , মোবাইল, চলতি_মাসের_নাম,মাসিক_ভাড়ার_পরিমান,বকেয়া,মোট_টাকার_পরিমান,পরিশোধকৃত_টাকার_পরিমান,বকেয়া_রইল,তারিখ_ও_বার) 
          VALUES('$sl','$ভাড়াটিয়ার_নাম ','$মোবাইল', '$চলতি_মাসের_নাম','$মাসিক_ভাড়ার_পরিমান','$বকেয়া','$মোট_টাকার_পরিমান','$পরিশোধকৃত_টাকার_পরিমান ','$বকেয়া_রইল','$তারিখ_ও_বার')";
    
    if(mysqli_query($connection,$sql)==True){
      echo "Data INSERTED";
      header('location:index.php');#the use of header is to redirect the location
      #if we use header then after refreshing the value will not be inserted again and again
    }
    else{
      echo " Name not found ";
    }
  }

  }

  else{
    // echo "Failed to insert ";
  }

 

  
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>তথ্য সন্নিবেশ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <style type="text/css">

    body{
/*            background-image:url('images/bg2.png');
      background-size: 1200px 400px;
      background-repeat:no-repeat;*/
    /*  background-image:url('images/flower.png');
      background-size: 100px 100px;*/
    }
    .container{
      width: 40%;
      text-align: start;
      border-radius: 5px;
      background-color:#ECEFEF;
      box-shadow: 3px 7px 8px 7px #888888;
    }
    div{margin: 50px;}
    form{
      padding-top: 30px;
      padding-bottom: 30px;
    }
  </style>
</head>
<body>
  <div class="container text-start ps-5">
    <!-- bg-info-subtle border border-info -->
      <form action="insert.php" method="POST">
             SL : <input type="text" name="sl"><br><br>
  ভাড়াটিয়ার_নাম : <input type="text" name="ভাড়াটিয়ার_নাম"><br><br>
  মোবাইল : <input type="text" name="মোবাইল"><br><br>
  মাসের নাম : <input type="text" name="চলতি_মাসের_নাম"><br><br>
  মাসিক_ভাড়ার_পরিমান : <input type="text" name="মাসিক_ভাড়ার_পরিমান"><br><br>
  পূর্বের বকেয়া : <input type="text" name="বকেয়া"><br><br>
  <!-- মোট_টাকার_পরিমান : <input type="text" name="মোট_টাকার_পরিমান"><br><br> -->
  পরিশোধকৃত_টাকার_পরিমান : <input type="text" name="পরিশোধকৃত_টাকার_পরিমান"><br><br>
  <!-- বকেয়া_রইল : <input type="text" name="বকেয়া_রইল"><br><br> -->
  তারিখ_ও_বার : <input type="text" name="তারিখ_ও_বার"><br><br>
  <div class="d-flex " style="margin-top: 0px; margin-left: 0px; margin-bottom: 0px;">
      <input type="submit" name="submit" value="Insert" class="btn btn-success ">

   <a href="index.php" style="padding-left: 70%;"><img src="images/next7.png" height="47px" width="47px" ></a>
  </div>

</form>
  </div>



</body>
</html>
