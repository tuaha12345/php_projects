
<link rel="icon" href="images/f3.png" type="image/ico">
<style><?php include 'css/style.css'; ?></style>




<?php



  if(isset($_GET['deleteid']) )
{ 
  
  require('connection.php');
  $deleteid=$_GET['deleteid'];
  $sql="DELETE FROM বাড়িভাড়া  WHERE sl='$deleteid' ";
  $query=$connection->query($sql);
  if ($query==True)
 { 
  header('location:index.php');
  echo 'Data deleted sucessfully!';
 }
}





?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
	<title style="color:red;">বাড়িওয়ালা</title>

</head>
<body class="">


	<div class="pt-5">
		<div class="main_div p-2">
			 <div class="inner">
        
			 	<div class="text-center mb-5 ">
			 		<h1>আব্দুর রহমান ভিলা </h1>
          <h4>দাপা ইদ্রাকপুর(সর্দারবাড়ি মসজিদ বাজার রোড)ফতুল্লা নারায়ণগঞ্জ</h4>
          <h6>মোবাইল : 0১৭৫২০৩৬২৮৫ , 0১৮৩৭৭৫৫৬৩৪</h6>
			 	</div>





         <table  class="table" style="border:2px solid dimgray;">
           <thead>
             <th>
               <strong>SL</strong>
             </th>
             <th>
               <strong>ভাড়াটিয়ার_নাম</strong>
             </th>
             <th>
               <strong>মোবাইল</strong>
             </th>
              <th>
               <strong>মাসের নাম</strong>
             </th>
              <th>
               <strong>মাসিক_ভাড়া</strong>
             </th>
              <th>
               <strong>পূর্বের বকেয়া</strong>
             </th>
              <th>
               <strong>মোট_টাকা</strong>
             </th>
             <th>
               <strong>পরিশোধকৃত_টাকা</strong>
             </th>
              <th>
               <strong style="color:red;">বকেয়া_রইল/টাকা পাবো</strong>
             </th>
              <th>
               <strong>তারিখ_ও_বার</strong>
             </th>


             <th colspan="2">
              <strong class="ps-4">Action:</strong>
             </th>

           </thead>

           <tbody>
               <?php 
                 require('connection.php');

                  $sql="SELECT * FROM বাড়িভাড়া ";
                  $result=$connection->query($sql);

                     while ($data=mysqli_fetch_assoc($result)) {

                                            $sl=$data['SL'];
																			      $ভাড়াটিয়ার_নাম=$data['ভাড়াটিয়ার_নাম'];
                                            $মোবাইল=$data['মোবাইল'];
																			      $চলতি_মাসের_নাম=$data['চলতি_মাসের_নাম'];
																			      $মাসিক_ভাড়ার_পরিমান=$data['মাসিক_ভাড়ার_পরিমান'];
																			      $বকেয়া=$data['বকেয়া'];
																			      $মোট_টাকার_পরিমান=$data['মোট_টাকার_পরিমান'];
																			      $পরিশোধকৃত_টাকার_পরিমান=$data['পরিশোধকৃত_টাকার_পরিমান'];
																			      $বকেয়া_রইল=$data['বকেয়া_রইল'];
																			      $তারিখ_ও_বার=$data['তারিখ_ও_বার'];


                                            echo 
                                            " 
                                            <tr>
                                            <td>$sl</td>
                                             <td>$ভাড়াটিয়ার_নাম</td>
                                             <td>$মোবাইল</td>
                                            <td style='text-align: center;'>$চলতি_মাসের_নাম</td>
                                            <td style='text-align: center;'>$মাসিক_ভাড়ার_পরিমান</td>
                                            <td style='text-align: center;'>$বকেয়া</td>
                                            <td style='text-align: center;'>$মোট_টাকার_পরিমান</td>
                                            <td style='text-align: center;'>$পরিশোধকৃত_টাকার_পরিমান</td>
                                            <td style='color:red;text-align: center;'>$বকেয়া_রইল</td>
                                            <td>$তারিখ_ও_বার</td>
                                            <td>
                                            <button class='btn btn-info'>
                                            <a href='edit.php? id=$sl' class='text-white text-decoration-none'>Edit</a>
                                            </button
                                            </td>
                                            <td>

                                            <button class='btn btn-danger'>
                                            <a  class='text-white text-decoration-none delete' onclick=myfun($sl)>Delete</a>
                                            </button

                                            </td>
                                            </tr>

                                            ";

                                            

              }

               ?>
           </tbody>

      </table>

    
    <div class="container py-5 my-5">
      <h4 class="pb-3">আপনি কি নতুন তথ্য সন্নিবেশ করতে চান?</h4>
      <a class="btn btn-success mx-2" href="insert.php" role="button">Yes</a>
      <a class="btn btn-danger ms-1" href="index.php" role="button">No</a>
    </div>



			 </div>

		</div>
	</div>

  <script type="text/javascript">
    function myfun(a) {
       if(confirm("আপনি কি এই সারি মুছে ফেলার বিষয়ে নিশ্চিত?"))
       {
        window.location.href='index.php? deleteid='+a+'';
        return true;
       }
    }
  </script>

</body>
</html>













